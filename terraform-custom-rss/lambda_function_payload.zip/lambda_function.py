import json
import requests
import csv
import boto3
import os
import xml.etree.ElementTree as ET
from datetime import datetime

# AWS Resources
s3 = boto3.client('s3')
ses = boto3.client('ses', region_name='us-east-2')
dynamodb = boto3.resource('dynamodb', region_name='us-east-2')
table = dynamodb.Table('JobListings')

# Configuration
RSS_FEED_URLS = [
    "https://rss.app/feeds/CLmqdD26b4Nxs8Mz.xml"
]  # Existing feed from RSS.app
S3_BUCKET = "hs-my-jobsearch-bucket"
S3_FILE_NAME = f"jobs_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.csv"
EMAIL_SENDER = "hsantana@renacentis.org"
EMAIL_RECIPIENT = "hsantana@renacentis.org"

def is_job_new(job_link):
    """Check if a job already exists in DynamoDB."""
    response = table.get_item(Key={'job_link': job_link})
    return 'Item' not in response

def save_job_to_dynamodb(job_link, title, pub_date, source):
    """Store new job in DynamoDB to prevent duplicates."""
    table.put_item(Item={
        'job_link': job_link,
        'title': title,
        'pub_date': pub_date,
        'source': source
    })

def fetch_rss_jobs():
    """Fetch job listings from existing RSS feed(s)."""
    jobs = []
    for feed_url in RSS_FEED_URLS:
        response = requests.get(feed_url)
        if response.status_code != 200:
            print(f"❌ Failed to fetch RSS feed: {feed_url} - Status Code: {response.status_code}")
            continue
        root = ET.fromstring(response.content)
        for item in root.findall(".//item"):
            title = item.find("title").text or "No Title"
            link = item.find("link").text or "No Link"
            pub_date = item.find("pubDate").text or "No Date"
            if is_job_new(link):
                jobs.append([title, link, pub_date, feed_url])
                save_job_to_dynamodb(link, title, pub_date, feed_url)
    print(f"✅ Fetched {len(jobs)} jobs from RSS.app")
    return jobs

def fetch_remoteok_jobs():
    """Fetch job listings from RemoteOK."""
    try:
        response = requests.get("https://remoteok.io/api")
        print(f"🔍 RemoteOK API Status Code: {response.status_code}")

        if response.status_code != 200:
            print(f"❌ Failed to fetch RemoteOK jobs. Status: {response.status_code}")
            return []

        jobs = response.json()
        if not isinstance(jobs, list) or len(jobs) <= 1:
            print(f"⚠️ Unexpected API response: {jobs}")
            return []

        jobs = jobs[1:]  # Skip metadata entry

        results = []
        for job in jobs:
            title = job.get('position', 'No Title')
            tags = job.get('tags', [])  # Tags are in a list
            description = job.get('description', '')

            # Convert everything to lowercase for better matching
            title_lower = title.lower()
            tags_lower = [tag.lower() for tag in tags]
            description_lower = description.lower()

            # ✅ Improved filtering: Match against title, tags, or description
            if any(keyword in title_lower for keyword in ["aws", "cloud", "devops"]) or \
               any(keyword in tags_lower for keyword in ["aws", "cloud", "devops"]) or \
               any(keyword in description_lower for keyword in ["aws", "cloud", "devops"]):

                link = job.get('url', 'No URL')
                pub_date = job.get('date', 'No Date')
                source = "RemoteOK"

                if is_job_new(link):
                    results.append([title, link, pub_date, source])
                    save_job_to_dynamodb(link, title, pub_date, source)
                    print(f"✅ Added new job: {title}")

        print(f"📌 Total RemoteOK Jobs Fetched: {len(results)}")
        return results

    except Exception as e:
        print(f"❌ Error fetching from RemoteOK: {str(e)}")
        return []

def fetch_weworkremotely_jobs():
    """Fetch job listings from We Work Remotely."""
    try:
        response = requests.get("https://weworkremotely.com/categories/remote-programming-jobs.rss")
        root = ET.fromstring(response.content)
    except Exception as e:
        print("❌ Error fetching from We Work Remotely:", e)
        return []
    results = []
    for item in root.findall(".//item"):
        title = item.find("title").text or "No Title"
        link = item.find("link").text or "No Link"
        pub_date = item.find("pubDate").text or "No Date"
        source = "We Work Remotely"
        if is_job_new(link):
            results.append([title, link, pub_date, source])
            save_job_to_dynamodb(link, title, pub_date, source)
    print(f"✅ Fetched {len(results)} jobs from We Work Remotely")
    return results

def generate_rss(jobs):
    """Generate an RSS XML feed from the job listings."""
    rss = ET.Element("rss", version="2.0")
    channel = ET.SubElement(rss, "channel")
    ET.SubElement(channel, "title").text = "AWS Cloud Engineer Jobs"
    ET.SubElement(channel, "link").text = "https://your-api-gateway-endpoint.com/jobs/rss"
    ET.SubElement(channel, "description").text = "Aggregated AWS Cloud Engineer Job Listings"
    ET.SubElement(channel, "lastBuildDate").text = datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")

    for job in jobs:
        item = ET.SubElement(channel, "item")
        ET.SubElement(item, "title").text = job[0]
        ET.SubElement(item, "link").text = job[1]
        ET.SubElement(item, "description").text = job[0]  # or another field as needed
    return ET.tostring(rss, encoding='utf-8', method='xml')

def lambda_handler(event, context):
    """AWS Lambda entry point."""
    try:
        # Fetch jobs from all sources
        jobs = fetch_rss_jobs()
        jobs += fetch_remoteok_jobs()
        jobs += fetch_weworkremotely_jobs()

        print(f"🛠 Total Jobs Fetched: {len(jobs)}")  # ✅ DEBUG: Log number of jobs
        print(jobs)  # ✅ DEBUG: Print job details for verification

        # If no jobs are collected, return an error for debugging
        if not jobs:
            return {
                "statusCode": 500,
                "body": json.dumps("⚠️ No jobs were fetched. Check your source URLs.")
            }

        # ✅ Ensure at least one test job appears in the RSS feed
        if len(jobs) == 0:
            jobs.append(["Test Job", "https://example.com/job", "Mon, 17 Mar 2025 18:55:19 GMT", "Test Source"])

        # Generate the RSS XML feed
        rss_feed = generate_rss(jobs)

        # Return the RSS feed as the HTTP response
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/rss+xml'},
            'body': rss_feed.decode('utf-8') if isinstance(rss_feed, bytes) else rss_feed
        }

    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return {"statusCode": 500, "body": json.dumps(str(e))}

if __name__ == "__main__":
    # For local testing
    response = lambda_handler({}, None)
    print(response["body"])
